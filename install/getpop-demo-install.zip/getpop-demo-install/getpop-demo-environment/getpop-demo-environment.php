<?php
/*
Plugin Name: GetPoP Demo Environment
Version: 1.0
Description: Environment Constants for the GetPoP Demo Website
Plugin URI: https://getpop.org/
Author: Leonardo Losoviz
Author URI: https://getpop.org/u/leo/
*/

define ('GETPOPDEMO_ENVIRONMENT_VERSION', 0.101);

// Priority 5: execute before everything else, to set all the environment constants
// That is needed to set the pop-aws CDN URI
add_action('plugins_loaded', 'getpopdemo_environment_init', 5);
function getpopdemo_environment_init() {
	require_once 'plugins/load.php';
}