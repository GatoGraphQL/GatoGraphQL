<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * IDs Configuration
 *
 * ---------------------------------------------------------------------------------------------------------------*/

//-----------------------
// New pages
//-----------------------
define ('POP_AAL_PAGE_NOTIFICATIONS', 22465);
define ('POP_AAL_PAGE_NOTIFICATIONS_MARKALLASREAD', 22467);
define ('POP_AAL_PAGE_NOTIFICATIONS_MARKASREAD', 22469);
define ('POP_AAL_PAGE_NOTIFICATIONS_MARKASUNREAD', 22471);

//-----------------------
// Existing pages/users
//-----------------------
define ('POP_AAL_USERALIAS_SYSTEMNOTIFICATIONS', 1813); // PoP
define ('POP_AAL_PAGEALIAS_USERWELCOME', 16114); // Page: About us => Our Mission
