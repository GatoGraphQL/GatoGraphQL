<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * IDs Configuration
 *
 * ---------------------------------------------------------------------------------------------------------------*/

// Categories
//--------------------------------------------------------
define ('POPTHEME_WASSUP_CATEGORYPROCESSORS_CAT_CATEGORYWEBPOSTS00', 1686); // Articles
define ('POPTHEME_WASSUP_CATEGORYPROCESSORS_CAT_CATEGORYWEBPOSTS01', 1684); // Announcements
define ('POPTHEME_WASSUP_CATEGORYPROCESSORS_CAT_CATEGORYWEBPOSTS02', 1687); // Resources

// Pages from the Main Navigation
//--------------------------------------------------------
define ('POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_CATEGORYWEBPOSTS00', 16103); // Articles
define ('POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_CATEGORYWEBPOSTS01', 16101); // Announcements
define ('POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_CATEGORYWEBPOSTS02', 23702); // Resources

// Define the constants from the theme
//--------------------------------------------------------
// Categories
//--------------------------------------------------------
define ('GETPOPDEMO_CAT_ARTICLES', POPTHEME_WASSUP_CATEGORYPROCESSORS_CAT_CATEGORYWEBPOSTS00);
define ('GETPOPDEMO_CAT_ANNOUNCEMENTS', POPTHEME_WASSUP_CATEGORYPROCESSORS_CAT_CATEGORYWEBPOSTS01);
define ('GETPOPDEMO_CAT_RESOURCES', POPTHEME_WASSUP_CATEGORYPROCESSORS_CAT_CATEGORYWEBPOSTS02);

// Pages
//--------------------------------------------------------
define ('GETPOPDEMO_PAGE_ARTICLES', POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_CATEGORYWEBPOSTS00);
define ('GETPOPDEMO_PAGE_ANNOUNCEMENTS', POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_CATEGORYWEBPOSTS01);
define ('GETPOPDEMO_PAGE_RESOURCES', POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_CATEGORYWEBPOSTS02);

// My Pages
//--------------------------------------------------------
define ('GETPOPDEMO_PAGE_MYARTICLES', POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_MYCATEGORYWEBPOSTS00);
define ('GETPOPDEMO_PAGE_MYANNOUNCEMENTS', POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_MYCATEGORYWEBPOSTS01);
define ('GETPOPDEMO_PAGE_MYRESOURCES', POPTHEME_WASSUP_CATEGORYPROCESSORS_PAGE_MYCATEGORYWEBPOSTS02);


