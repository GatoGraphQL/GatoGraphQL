<?php

require_once 'config/load.php';
