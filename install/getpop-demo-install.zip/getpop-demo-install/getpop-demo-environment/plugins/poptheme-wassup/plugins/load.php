<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * Custom Implementation Library
 *
 * ---------------------------------------------------------------------------------------------------------------*/

if (class_exists('EM_Event'))	
	require_once 'events-manager/load.php';

if (class_exists("RGForms"))	
	require_once 'gravityforms/load.php';
