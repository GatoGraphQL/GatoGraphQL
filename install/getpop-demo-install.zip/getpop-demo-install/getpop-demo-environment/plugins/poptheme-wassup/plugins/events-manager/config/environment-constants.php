<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * IDs Configuration
 *
 * ---------------------------------------------------------------------------------------------------------------*/

// NOT IMPLEMENTED YET BUT DEFINED IN CODE
define ('POPTHEME_WASSUP_EM_PAGE_MANAGEBOOKINGS', 0);


// Categories
//--------------------------------------------------------
define ('POPTHEME_WASSUP_EM_CAT_ALL', 1514);
define ('POPTHEME_WASSUP_EM_CAT_FUTURE', 1524);
define ('POPTHEME_WASSUP_EM_CAT_CURRENT', 1556);
define ('POPTHEME_WASSUP_EM_CAT_PAST', 1525);
define ('POPTHEME_WASSUP_EM_CAT_EVENTLINKS', 1612);

// Pages from the Main Navigation
//--------------------------------------------------------
define ('POPTHEME_WASSUP_EM_PAGE_EVENTS', 16087);
define ('POPTHEME_WASSUP_EM_PAGE_EVENTSCALENDAR', 16089);
define ('POPTHEME_WASSUP_EM_PAGE_PASTEVENTS', 16093);

// Modals
//--------------------------------------------------------
define ('POP_EM_POPPROCESSORS_PAGE_ADDLOCATION', 16160);
define ('POP_EM_POPPROCESSORS_PAGE_LOCATIONSMAP', 20071);


// Add / Edit / List Content Pages
//--------------------------------------------------------
define ('POPTHEME_WASSUP_EM_PAGE_MYEVENTS', 16198);
define ('POPTHEME_WASSUP_EM_PAGE_MYPASTEVENTS', 18625);
define ('POPTHEME_WASSUP_EM_PAGE_ADDEVENT', 16200);	
define ('POPTHEME_WASSUP_EM_PAGE_ADDEVENTLINK', 21553);	
define ('POPTHEME_WASSUP_EM_PAGE_EDITEVENT', 16202);	
define ('POPTHEME_WASSUP_EM_PAGE_EDITEVENTLINK', 21555);	
