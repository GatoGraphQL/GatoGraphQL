<?php

require_once 'config/load.php';
require_once 'plugins/load.php';
