<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * IDs Configuration
 *
 * ---------------------------------------------------------------------------------------------------------------*/

// System Pages
//--------------------------------------------------------
define ('POP_SYSTEM_PAGE_SYSTEM_POPINSTALL', 23821);

// Private Keys
//--------------------------------------------------------
define ('POP_SYSTEM_APIKEYS_SYSTEMACCESS', 'qMp6xP2uU2rgYqbo5aFAgAv5vT4kfAjz');
define ('POP_SYSTEM_IPS_SYSTEMACCESS', array('localhost', '127.0.0.1', '::1'));
