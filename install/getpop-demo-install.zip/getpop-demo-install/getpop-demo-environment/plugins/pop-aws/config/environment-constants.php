<?php

/**---------------------------------------------------------------------------------------------------------------
 * Config for DEV
 * ---------------------------------------------------------------------------------------------------------------*/

// Configuration for AWS for IAM user getpopdemo-dev
// They might've been defined by plugin "Amazon Web Services" already
if (!defined('AWS_ACCESS_KEY_ID')) {
	define( 'AWS_ACCESS_KEY_ID', 'AKIAI2OOP5ZUCR3I52PA');
	define( 'AWS_SECRET_ACCESS_KEY', '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');
}

define( 'POP_AWS_REGION', 'ap-southeast-1');

// Target bucket: where to copy the userphoto when the user presses "save"
define( 'POP_AWS_UPLOADSBUCKET', 'getpop-demo-dev');
