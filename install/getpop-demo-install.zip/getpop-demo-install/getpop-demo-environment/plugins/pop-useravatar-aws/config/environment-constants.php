<?php

// Working Bucket: where the file upload takes place
define( 'POP_FILEUPLOAD_AWS_WORKINGBUCKET', 'getpop-demo-fileupload-dev');