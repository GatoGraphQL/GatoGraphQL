<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * Custom Implementation Library
 *
 * ---------------------------------------------------------------------------------------------------------------*/

require_once 'pop-wpapi/load.php';
require_once 'pop-coreprocessors/load.php';
require_once 'events-manager-popprocessors/load.php';
require_once 'poptheme-wassup/load.php';
require_once 'poptheme-wassup-categoryprocessors/load.php';
require_once 'poptheme-wassup-sectionprocessors/load.php';
require_once 'aryo-activity-log-pop/load.php';

if (defined('POP_SYSTEM_VERSION')) {
	require_once 'pop-system/load.php';		
}
if (defined('POP_SERVICEWORKERS_VERSION')) {
	require_once 'pop-serviceworkers/load.php';		
}

if (class_exists('User_Role_Editor'))		
	require_once 'user-role-editor/load.php';
