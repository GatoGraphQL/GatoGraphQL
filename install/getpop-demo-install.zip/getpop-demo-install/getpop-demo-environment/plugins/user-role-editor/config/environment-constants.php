<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * IDs Configuration
 *
 * ---------------------------------------------------------------------------------------------------------------*/

// define ('POP_WPAPI_AVATAR_GENERICUSER_INDIVIDUAL', 1593); // username: admin_default_avatar_individual
// define ('POP_WPAPI_AVATAR_GENERICUSER_ORGANIZATION', 1594); // username: admin_default_avatar_organization

define ('POP_URE_POPPROCESSORS_PAGE_COMMUNITIES', 17478);
define ('POP_URE_POPPROCESSORS_PAGE_ORGANIZATIONS', 16079);
define ('POP_URE_POPPROCESSORS_PAGE_INDIVIDUALS', 16083);

define ('POP_URE_POPPROCESSORS_PAGE_MEMBERS', 18611);

define ('POP_URE_POPPROCESSORS_PAGE_ADDPROFILEORGANIZATION', 16147);
define ('POP_URE_POPPROCESSORS_PAGE_ADDPROFILEINDIVIDUAL', 16149);
define ('POP_URE_POPPROCESSORS_PAGE_EDITPROFILEORGANIZATION', 18619);
define ('POP_URE_POPPROCESSORS_PAGE_EDITPROFILEINDIVIDUAL', 18621);
define ('POP_URE_POPPROCESSORS_PAGE_MYCOMMUNITIES', 18623);
define ('POP_URE_POPPROCESSORS_PAGE_MYMEMBERS', 18970);
define ('POP_URE_POPPROCESSORS_PAGE_INVITENEWMEMBERS', 18925);
define ('POP_URE_POPPROCESSORS_PAGE_EDITMEMBERSHIP', 19103);

