<?php

/**---------------------------------------------------------------------------------------------------------------
 *
 * IDs Configuration
 *
 * ---------------------------------------------------------------------------------------------------------------*/

// Categories
//--------------------------------------------------------
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_CAT_BLOG', 1105);
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_CAT_UNCATEGORIZED', 1423);

// About us Pages
//--------------------------------------------------------
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_PAGE_BLOG', 16109);
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_PAGE_ABOUT', 16068);
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_PAGE_ABOUT_HOWTOUSEWEBSITE', 20810);
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_PAGE_ABOUT_CONTENTGUIDELINES', 22459);
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_PAGE_ABOUT_OURMISSION', 16114);
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_PAGE_ABOUT_WHOWEARE', 16116);
define ('POPTHEME_WASSUP_SECTIONPROCESSORS_PAGE_ABOUT_INTHEMEDIA', 18866);
