<?php

/**---------------------------------------------------------------------------------------------------------------
 * Config for DEV
 * ---------------------------------------------------------------------------------------------------------------*/

// Configuration for AWS for IAM user pop-emailsender-dev
define('POP_MAILER_AWS_ACCESS_KEY_ID', 'AKIAJWGWJZF23YX5U4IQ');
define('POP_MAILER_AWS_SECRET_ACCESS_KEY', '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');
define('POP_MAILER_AWS_REGION', 'us-east-1');
define('POP_MAILER_AWS_BUCKET', 'pop-emailsender-usstandard');
// define('POP_MAILER_AWS_PATH', 'emails/'.POP_WEBSITE.'/');
define('POP_MAILER_AWS_PATH', 'emails/'.POP_WEBSITE.'-dev/');
